import streamlit as st
from utils.database import supabase

# Make sure user is logged in
if "user" in st.session_state:
    user = st.session_state["user"]

    # Check if profile exists
    profile_res = supabase.table("parents").select("*").eq("user_id", user.id).execute()
    profile = profile_res.data[0] if profile_res.data else None

    if profile:
        st.success(f"Welcome back, {profile.get('parent_name')}!")

        st.subheader("Child Details")
        c_name, c_grade, c_school = st.columns([2,1,2])
        c_name.markdown(f"**Name**\n\n{profile.get('child_name', '—')}")
        c_grade.markdown(f"**Grade**\n\n{profile.get('grade', '—')}")
        c_school.markdown(f"**School**\n\n{profile.get('school', '—')}")

        st.markdown("---")

        # Centered booking action: clickable icon + label
        b1, b2, b3 = st.columns([1,2,1])
        with b2:
            if st.button("📝  Proceed to Booking", key="parent_proceed_booking"):
                try:
                    st.switch_page("pages/parent_booking.py")
                except Exception:
                    st.experimental_rerun()
    else:
        st.warning("Please complete your profile to proceed.")

        parent_name = st.text_input("Parent Name")
        phone = st.text_input("Phone Number")
        child_name = st.text_input("Child Name")
        grade = st.text_input("Child Grade")
        school = st.text_input("Child School")

        if st.button("Save Profile"):
            if parent_name and phone and child_name and grade and school:
                insert_res = supabase.table("parents").insert({
                    "user_id": user.id,
                    "parent_name": parent_name,
                    "phone": phone,
                    "child_name": child_name,
                    "grade": grade,
                    "school": school
                }).execute()

                if getattr(insert_res, 'error', None) is None and insert_res.data:
                    st.success("Profile saved successfully! You can now book a reader/scribe.")
                    try:
                        st.experimental_rerun()
                    except Exception:
                        st.markdown("<script>window.location.reload()</script>", unsafe_allow_html=True)
                else:
                    st.error(f"Failed to save profile. Error: {getattr(insert_res, 'error', None)}")
            else:
                st.error("Please fill in all fields.")
else:
    st.info("Please log in first via the Parent Portal.")
